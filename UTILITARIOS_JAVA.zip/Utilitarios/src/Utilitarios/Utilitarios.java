package Utilitarios;


import java.io.File;
import java.text.DateFormat;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Utilitarios {
	
	
	
	public static boolean existeArquivo(String caminhoArq) {

		File arquivo = new File(caminhoArq);

		return arquivo.exists() && arquivo.isFile();

	}
	
	public static void movendoArquivo(String caminhoOrigem, String caminhoDestino){
    // arquivo a ser movido
    File arquivo = new File(caminhoOrigem);

    // diretorio de destino
    File dir = new File(caminhoDestino);

    // move o arquivo para o novo diretorio
    boolean ok = arquivo.renameTo(new File(dir, arquivo.getName()));
    if(ok){
        System.out.println("Arquivo foi movido com sucesso");
    }
    else{
        System.out.println("Nao foi possivel mover o arquivo");
    }
    }
	
	public static String formatarData(GregorianCalendar dt, String fmt) {
		try {
			SimpleDateFormat formatoData = new SimpleDateFormat(fmt);
			return formatoData.format(dt.getTime());
		} catch (Exception e) {
			return "Formato inv�lido";
		}

	}
	 
	public static String checaFDS(Calendar data,Integer qtd)
	    {
		data.add(Calendar.DAY_OF_MONTH,qtd);
		//;;System.out.println(data + "TESTE");
		
	        // se for domingo
	        if (data.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
	        {
	            data.add(Calendar.DATE, 1);
	           // System.out.println("Eh domingo, mudando data para +1 dias");
	            return "domingo";
	        }
	        // se for s�bado
	        else if (data.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)
	        {
	            data.add(Calendar.DATE, 2);
	            //System.out.println("Eh sabado, mudando data para +2 dias");
	            return "sabado";
	        }
	        else
	        {
	           // System.out.println("Eh dia de semana, mantem data");
	            return "semana";
	        }
	    }

	
	
	
	  public static String removeAcentos(String str) {  
		    CharSequence cs = new StringBuilder(str == null ? "" : str);  
		    return Normalizer.normalize(cs, Normalizer.Form.NFKD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");  
      } 
	
	  
	  public static String normalizeXML(String xml) { 
		  if ((xml != null) && (!"".equals(xml))) { 
		  xml = xml.replaceAll("\\r\\n", ""); 
		  xml = xml.replaceAll(" standalone=\"no\"", ""); 
		  while (xml.indexOf(" <") != -1){ 
		  xml = xml.replaceAll(" <", "<"); 
		  } 
		  } 
		  return xml; 
		  }
	  
		 public static boolean validEmail(String email) {
			    System.out.println("Metodo de validacao de email");
			    Pattern p = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$"); 
			    Matcher m = p.matcher(email); 
			    if (m.find()){
			      System.out.println("O email "+email+" e valido");
			      return true;
			    }
			    else{
			      System.out.println("O E-mail "+email+" � inv�lido");
			      return false;
			    }  
			 }

	 public static String retornaMes(Integer mes){
		 
		 
		 
	      Object [] listaMes =  new Object[12];
	       
	        listaMes[0] = "JANEIRO";
	        listaMes[1] = "FEVEREIRO";
	        listaMes[2] = "MAR�O";
	        listaMes[3] = "ABRIL";
	        listaMes[4] = "MAIO";
	        listaMes[5] = "JUNHO";
	        listaMes[6] = "JULHO";
	        listaMes[7] = "AGOSTO";
	        listaMes[8] = "SETEMBRO";
	        listaMes[9] = "OUTUBRO";
	        listaMes[10] = "NOVEMBRO";
	        listaMes[11] = "DEZEMBRO";
	        
	        
	        return (String) listaMes[mes];
	 }

	 public static String replaceLast(String texto, String substituir, String substituto) {
		    // Retorna o �ndice da �ltima ocorr�ncia de "substituir"
		    int pos = texto.lastIndexOf(substituir); 
		    // Se encontrar o �ndice
		    if (pos > -1) { 
		       // Retorna os caracteres antecedentes de "substituir"
		       return texto.substring(0, pos) 
		        + substituto
		        // Retorna os caracteres posteriores a "substituir"
		        + texto.substring(pos + substituir.length(), texto.length()); 
		    } else 
		       // Se a palavra especificada em "substituir" n�o for encontrada n�o altera nada
		       return texto;
		}
	 
	 public static String tratandoDataAMPM(String dataInformada){
	        //EXEMPLO DATA: 2016-04-11 1:26 pm   
		// dataInformada = (dataInformada.replace('"','|'));
	            String dataLandPage[] = dataInformada.split(" ");            
	            String data = dataLandPage[0];
	            System.out.println("data:"+data);
	            String horaLandPage[] = dataLandPage[1].split(":");
	            String hora = horaLandPage[0];
	            String min  = horaLandPage[1];
	            System.out.println("horaLandPage[0]"+horaLandPage[0]);
	            
	            String ampm = dataLandPage[2];
	            
	            if(ampm.toUpperCase().equals("PM")){
	                if(Integer.parseInt(hora) < 12){
	                    Integer horaInt = Integer.parseInt(hora);
	                    horaInt = horaInt + 12;
	                    hora = horaInt.toString();
	                }
	            }
	            
	            System.out.println("DATA FORMATADA:"+data+" "+hora+":"+min);
	                            
	            String dataFormatada = data+"T"+hora+":"+min+":00+0100";
	            
	            return dataFormatada;
	    }
	 
	 public static String tratandoDataAMPMCORRETA(String dataInformada){
	        //EXEMPLO DATA: 2016-04-11 1:26 pm   
		// dataInformada = (dataInformada.replace('"','|'));
	            String dataLandPage[] = dataInformada.split(" ");            
	            String data = dataLandPage[0];
	            System.out.println("data:"+data);
	            String horaLandPage[] = dataLandPage[1].split(":");
	            String hora = horaLandPage[0];
	            String min  = horaLandPage[1];
	            System.out.println("horaLandPage[0]"+horaLandPage[0]);
	            
	            String ampm = dataLandPage[2];
	            
	            if(ampm.toUpperCase().equals("PM")){
	                if(Integer.parseInt(hora) < 12){
	                    Integer horaInt = Integer.parseInt(hora);
	                    horaInt = horaInt + 12;
	                    hora = horaInt.toString();
	                }
	            }
	            
	            System.out.println("DATA FORMATADA:"+data+" "+hora+":"+min);
	                            
	            String dataFormatada = data;
	            
	            return dataFormatada;
	    }
	 
	 
	 public static ArrayList retornoListaPeriodo(Date datafim,Integer periodo) throws ParseException{
		
		  //  System.out.println(datafim+" LEITE");
		    
		    ArrayList<String> listaData = new ArrayList();
            Integer contador = 0;
		    Date datafim2 = datafim;
		    int numeroDiasParaSubtrair = -1;
		    while (contador < periodo ) {
			
		    	
	            
		    	
		    	
		    	   Calendar calendarData = Calendar.getInstance();
		           calendarData.setTime(datafim2);
		         
		           // achar data de in�cio
		           calendarData.add(Calendar.DATE,numeroDiasParaSubtrair);
		           datafim2 = calendarData.getTime();
		    	
		             Date datedataCadastro = null;  
		              DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		             Calendar cal = Calendar.getInstance();
		             System.out.println(df.format(datafim2));
		       
		         
		           listaData.add(df.format(datafim2));
		           
		    	contador ++;
				
			}
		 
		 
		 
		 return listaData;
	 }
	 
	 public static String onlyNumbers(String str) {
		
		    if (str != null) {
		
		       return str.replaceAll("[^0123456789]", "");
		
		    } else {
		
		       return "";
		
		    }
		
		 }

	 
	 public static String limpacpfcnpj(String logclisit_cpfcnpj){
		 
		//    System.out.println(logclisit_cpfcnpj);
		      logclisit_cpfcnpj = logclisit_cpfcnpj.replace(".","");
			 logclisit_cpfcnpj = logclisit_cpfcnpj.replace("-","");
			 logclisit_cpfcnpj = logclisit_cpfcnpj.replace(" ","");
			 logclisit_cpfcnpj = logclisit_cpfcnpj.replace("\"","");
			 logclisit_cpfcnpj = Utilitarios.onlyNumbers(logclisit_cpfcnpj);
			 
			 if(logclisit_cpfcnpj.length() < 2){
				 
				 return logclisit_cpfcnpj = "0";
				 
			 }
			 
			 
			 
			 return logclisit_cpfcnpj;
		 
	 }
	 
	 public static boolean verificaData(Date emissao, Date vencimento){
			boolean data;
			if (emissao.before(vencimento)){
				data = true;
			}
			else if (emissao.after(vencimento))
				data = false;
			else
				data = true;
			return data;
		}

}
