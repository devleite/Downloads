package banco;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class utilBanco {
	
	
	/**
	 * CONEXAO COM BANCO
	 * @author devleite
	 */
	public static void updateInserir(Connection conn, String sql, Object...objects) throws SQLException{
		
		
		PreparedStatement pstm = conn.prepareStatement(sql);
		Integer cont = objects.length;
		//System.out.println(objects.length);
		while(0 < cont){
			//System.out.println(objects.length+"Leite");
			
			//System.out.println(objects.length);
			pstm.setObject(cont,objects[cont-1]);
			cont--;
		
		}
		pstm.executeUpdate();
		
				
	}
	
	
	//consulta 
	public static ResultSet consulta(Connection conn, String sql, Object...objects) throws SQLException{
		
		
		PreparedStatement pstm = conn.prepareStatement(sql);
		Integer fetchSize = objects.length;
		Integer cont = fetchSize;
		//System.out.println(sql);
		while(cont > 0){
	//	System.out.println(fetchSize+"Leite");
			
		//	System.out.println(objects[0]);
			Integer cont2 = cont - 1;
			
			String valor = (String) objects[cont2];
			//System.out.println(valor+" OPA �LEITE");
			pstm.setObject(cont,(objects[cont2]));
	
		cont--;
		}
		
		pstm.setFetchSize(fetchSize);
		ResultSet consulta = pstm.executeQuery();
		
		return consulta;
	}
	
	 public static void renameNome(String nomenew,String novoold,Connection conn) throws SQLException{
		 
		 String sqlnew = "ALTER TABLE "+novoold+" RENAME TO "+nomenew;
		 
		 utilBanco.updateInserir(conn, sqlnew);
	 
	 }


}
