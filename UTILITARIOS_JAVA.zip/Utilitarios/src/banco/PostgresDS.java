package banco;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class PostgresDS {



	private static PostgresDS instancia = new PostgresDS();
/**
	 * Retorna a inst�ncia da classe, Singleton.
	 * @return PostgresDS
	 */
	public static  PostgresDS getInstance(){

		return instancia;

	}




	/**Retorna uma conexao direta n�o gerenciada pelo Pool ao banco Postgres.
	 * @return Connection
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Connection getDevLeite() throws SQLException, ClassNotFoundException {

		Class.forName("org.postgresql.Driver");

		return DriverManager.getConnection(
				"jdbc:postgresql://IPBANCO:PORTA/NOMEBANCO",
				"USUARIOS","SENHA");
	

	}
	
	
}

