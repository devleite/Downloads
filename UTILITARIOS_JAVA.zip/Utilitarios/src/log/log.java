package log;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import Utilitarios.Utilitarios;

public class log {

	
	
	public static void escreveLog(String rotina, String texto) {

	Utilitarios util = new Utilitarios();

			String local = "/devleite/services/LOG";
			System.out.println(local);
		 	String dataAtual = util.formatarData(new GregorianCalendar(), "yyyyMMdd");
			String caminhoArquivo = local + File.separator + "LOG_" + dataAtual
					+ ".log";
			String linhaLog = util.formatarData(new GregorianCalendar(),
					"dd/MM/yyyy HH:mm:ss") + " - " + rotina + " - " + texto;
			System.out.println(linhaLog);
			try {

				File arquivo = new File(caminhoArquivo);

				if (!util.existeArquivo(caminhoArquivo))
					arquivo.createNewFile();

				FileWriter fw = new FileWriter(arquivo, true);
				BufferedWriter bw = new BufferedWriter(fw);

				String[] linhas = linhaLog.split("\n");
				for (int i = 0; i < linhas.length; i++) {

					bw.write(linhas[i]);
					bw.newLine();
					System.out.println("Escrevi no log " + linhas[i]);

				}
				bw.newLine();
				bw.flush();

				bw.close();
				fw.close();

			} catch (Exception e) {
				//return false;
			}

		}


	

}
