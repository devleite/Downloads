package arquivo;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import log.log;

public class Zip {
	
	/**
	 * Extrai um arquivo .Zip 
	 * @param camarquivo Caminho completo do Arquivo a ser extra�do.
	 * @param destino Pasta de destino (Caminho completo).
	 * @return True se conseguiu extrair.
	 * @author devleite
	 */
	public static boolean extrair(String camarquivo, String destino) {
		
		try {
			
			extrair(new File(camarquivo), destino);
			
			return true;
			
		} catch (Exception e) {
			
			log.escreveLog((Zip.class).toString(), e.toString());
			
			return false;
			
		}
		
		
		
	}
	
	/**
	 * Extrai um arquivo .Zip 
	 * @param arquivo Arquivo a ser extra�do
	 * @param destino Pasta de destino (Caminho completo) 
	 * @return String[] com caminho dos arquivos descompactados.
	 * @throws Exception 
	 */
	public static ArrayList<String> extrair(File arquivo, String destino) throws Exception {
		
			File pastaDest = new File(destino);
			
			if(!pastaDest.isDirectory())
				pastaDest.mkdir();
		
			byte[] buf = new byte[1024];
						
			ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(arquivo));
								
			ZipEntry zipentry = zipinputstream.getNextEntry();
			
			ArrayList<String> resp = new ArrayList<String>();
			
			
			//Para cada entrada dentro do arquivo Zip.
			while (zipentry != null) {
								
				String entryName = zipentry.getName();
					
				int n;
				
				FileOutputStream fileoutputstream;
				File newFile = new File(pastaDest, entryName);
				
				newFile.createNewFile();
				
				if(newFile.getParentFile() != null)
					newFile.mkdirs();
				
				if(newFile.isDirectory())
					continue;
				
				
				fileoutputstream = new FileOutputStream(newFile);

				while ((n = zipinputstream.read(buf, 0, 1024)) > -1)
					fileoutputstream.write(buf, 0, n);

				fileoutputstream.close();
				zipinputstream.closeEntry();
				zipentry = zipinputstream.getNextEntry();
				
				resp.add(destino + entryName);
				
			}// while

			zipinputstream.close();
			
			return resp;
			
	}
	
	/**
	 * Verifica se um arquivo � zip ou n�o.
	 * @param arquivo
	 * @return boolean
	 */
	public static boolean verificar(String arquivo){
		
		return verificar(new File(arquivo));
		
	}
		
	/**
	 * Verifica se um arquivo � zip ou n�o.
	 * @param arquivo
	 * @return boolean
	 */
	public static boolean verificar(File arquivo){
		
		try{
		
			ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(arquivo));
		
			if(zipinputstream.getNextEntry() == null){
				
				zipinputstream.close();
				return false;
				
			}
			
			zipinputstream.close();
			return true;
		
		}catch (Exception e){
			
			return false;
		}
		
		
	}
	
	/**
	 * Compacta arquivos para Zip
	 * @param arquivo Origem
	 * @param arquivoDest Arquivo Zip de destino	
	 * @return boolean
	 * @author vidmar.silveira
	 */
	public static boolean compactar(File arquivo, File arquivoDest){
		
		String[] arquivos = {arquivo.getAbsolutePath()};
		
		
		return compactar(arquivos, arquivoDest);
				
	}
	
	
	
	/**
	 * Compacta arquivos para Zip
	 * @param arquivos Array com endere��s de arquivos
	 * @param arquivoDest Arquivo Zip de destino	
	 * @return boolean
	 * @author vidmar.silveira
	 */
	public static boolean compactar(String[] arquivos, File arquivoDest){
		
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];

		try {
		    // Create the ZIP file
		      ZipOutputStream out = new ZipOutputStream(new FileOutputStream(arquivoDest));

		    // Compress the files
		    for (int i=0; i<arquivos.length; i++) {
		        FileInputStream in = new FileInputStream(arquivos[i]);
		        
		        ZipEntry zip = new ZipEntry(arquivos[i].substring(arquivos[i].lastIndexOf(File.separator) + 1));
		       
		        
		        // Add ZIP entry to output stream.
		        out.putNextEntry(zip);

		        // Transfer bytes from the file to the ZIP file
		        int len;
		        while ((len = in.read(buf)) > 0) {
		            out.write(buf, 0, len);
		        }

		        // Complete the entry
		        out.closeEntry();
		        in.close();
		    }

		    // Complete the ZIP file
		    out.close();
		    
		    return true;
		
		} catch (IOException e) {
			
			return false;
			
		}
		
	}
	
}


