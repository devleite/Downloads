package arquivo;

import banco.utilBanco;

import com.linuxense.javadbf.DBFException;
import com.linuxense.javadbf.DBFField;
import com.linuxense.javadbf.DBFWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * GERAR DBF
 * @author devleite
 */
public class GeraDBF {
    /* Numero de campos do DBF */
    private DBFField fields[] = new DBFField[1];

    private void defineCampos() {
    	
    	
        fields[0] = new DBFField();
        fields[0].setName("devleite");//nome do campo
        fields[0].setDataType(DBFField.FIELD_TYPE_N);//tipo do campo
        fields[0].setFieldLength(7);//tamanho do campo

        
    
    }

    public void geraArquivo(String caminho) throws  DBFException
                                                  , FileNotFoundException
                                                  , IOException, ClassNotFoundException {

        this.defineCampos();
        DBFWriter writer = new DBFWriter();
        writer.setFields(fields);
        

        	
        Object rowData[];
        rowData = new Object[1];
        rowData[0] = 8;//setar a posicao e o valor do campo

        
        writer.addRecord(rowData);
        
       FileOutputStream fos = new FileOutputStream("arquivo.dbf");
        writer.write(fos);
        fos.close();
    }
    
} 
