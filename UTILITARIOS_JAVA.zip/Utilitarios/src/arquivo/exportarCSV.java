package arquivo;


import java.io.FileWriter;
	import java.io.IOException;
	/**
	 * Exportar Arquivo csv 
	 * @param camarquivo valor a inserir o no csv .
	 * @param destino Pasta de destino (Caminho completo).
	 * @author devleite
	 */
	public class exportarCSV
	{
	   public static void main(String [] args)
	   {
		    //COLUNAS VC SEPARA COM ";" E QUEBRA DE LINHA COM VIRGULA
		   generateCsvFile("DEV;LEITE;TESTE,LINDO;BONITO;TESTE","test.csv"); 
	   }
	   
	   public static void generateCsvFile(String valor,String sFileName)
	   {
		try
		{
		    FileWriter writer = new FileWriter(sFileName);
			 
		    String[] elementos = valor.split(",");
		    Integer tamanho = elementos.length;
		    Integer contador = 0;
		     while(tamanho > 0){
		    
		    	    String[] elementos2 = (elementos[contador]).split(";");
				    Integer tamanho2 = elementos.length;
		            Integer contador2 = 0;
				     while(tamanho2 >0){
				        
				    	 writer.append(elementos2[contador2]);
		                 writer.append(';');
		                 
		                 tamanho2--;
		                 contador2++;
				     }
				     writer.append('\n');
				     tamanho--;
				     contador++;
				     
		    //generate whatever data you want
			 
		     }
		 	
			    writer.flush();
			    writer.close();
		}
		catch(IOException e)
		{
		     e.printStackTrace();
		} 
	    }
	}

