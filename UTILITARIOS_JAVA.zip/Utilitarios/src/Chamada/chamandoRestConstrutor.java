package Chamada;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.codehaus.jettison.json.JSONObject;

public class chamandoRestConstrutor {
	
	
	
	public Boolean restComObjeto(JSONObject objeto,URL url){
		
		Boolean retornoChamada = false;
		 try {
   	
   		   
   		      
   		      HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
   		      urlConnection.setDoOutput(true);
   		      urlConnection.setDoInput(true);

   	            // Define o content-type:
   		      urlConnection.setRequestProperty("Content-Type", "application/json");
   		     // urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");

   	            // Define o m�todo da requisi��o:
   		      urlConnection.setRequestMethod("POST");
   		
   		  
   		  
   		     System.out.println((objeto.toString()));
   		        try (OutputStream outputStream = urlConnection.getOutputStream()) {
   	                outputStream.write(objeto.toString().toString().getBytes("UTF-8"));
   	            }
   		       
   		       
   	            
   		   
   		      InputStream is = urlConnection.getInputStream();
   		      
   		     BufferedReader br2 = new BufferedReader(new InputStreamReader(is));
   		    
   		     System.out.println((br2).toString());
   		  	String retorno;
   		  	String retorno2 = "";
				while((retorno = br2.readLine()) != null)
   			{
					retorno2 =retorno;
   			}
            
				
				if(retorno2.contains("true")){
   		              System.out.println("CORRETO"+retorno2);
   		           retornoChamada = true;
				}

   		} catch (java.net.MalformedURLException e){
   		   System.out.println(e+"Erro ao criar URL. Formato inv�lido.");
   		} catch (IOException e2) {
   		   System.out.println(e2 +"Erro ao acessar URL.");
   		}
		 
		
		return retornoChamada;
	}
	
	
	

}
